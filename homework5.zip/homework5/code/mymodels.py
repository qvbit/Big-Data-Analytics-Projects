import torch
import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
import torch.nn.functional as F




class MyMLP(nn.Module):
    def __init__(self):
        super(MyMLP, self).__init__()
        self.hidden1 = nn.Linear(178, 64)
        self.hidden2 = nn.Linear(64, 16)
        self.out = nn.Linear(16, 5)

    def forward(self, x):
        x = F.relu(self.hidden1(x))
        x = F.relu(self.hidden2(x))
        x = self.out(x)
        return x


class MyCNN(nn.Module):
    def __init__(self):
        super(MyCNN, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=6, kernel_size=5)
        self.conv1_bn = nn.BatchNorm1d(6)
        self.pool = nn.MaxPool1d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv1d(in_channels=6, out_channels=16, kernel_size=5)
        self.conv2_bn = nn.BatchNorm1d(16)
        self.fc1 = nn.Linear(in_features=16*41, out_features=128)
        self.fc1_bn = nn.BatchNorm1d(128)
        self.fc2 = nn.Linear(128, 5)
        
    def forward(self, x):
#         x = self.pool(F.relu(self.conv1_bn(self.conv1(x))))
#         x = self.pool(F.relu(self.conv2_bn(self.conv2(x))))
#         x = x.view(-1, 16*41) # Flatten the output to a vector feed into dense layer
#         x = F.relu(self.fc1_bn(self.fc1(x)))
#         x = self.fc2(x)

        x = self.conv1_bn(self.pool(F.relu(self.conv1(x))))
        x = self.conv2_bn(self.pool(F.relu(self.conv2(x))))
        x = x.view(-1, 16*41) # Flatten the output to a vector feed into dense layer
        x = self.fc1_bn(F.relu(self.fc1(x)))
        x = self.fc2(x)
        return x


class MyRNN(nn.Module):
	def __init__(self):
		super(MyRNN, self).__init__()

	def forward(self, x):
		return x


class MyVariableRNN(nn.Module):
	def __init__(self, dim_input):
		super(MyVariableRNN, self).__init__()
		# You may use the input argument 'dim_input', which is basically the number of features

	def forward(self, input_tuple):
		# HINT: Following two methods might be useful
		# 'pack_padded_sequence' and 'pad_packed_sequence' from torch.nn.utils.rnn

		seqs, lengths = input_tuple

		return seqs